The goal of the library is that of allowing developers to quickly and easily gather relevant stock information about a company without having to spend too much time making sure that only the necessary information was gathered.

The functions in the package make use of requests_html, bs4, and csv libraries to make and save the requests.

The Historic Function has to be updated to allow for the new features

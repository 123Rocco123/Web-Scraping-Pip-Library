Web Scraping library.
All data is scraped off of Yahoo and Marketwatch

The goal of the library is that of allowing developers to quickly and easily gather relevant stock information about a company without having to spend too much time making sure that only the necessary information was gathered.

Documentation is the process of being created to improve the ease of use of the library.

The GitHub repository is located at: https://github.com/123Rocco123/Web-Scraping-Pip-Library
